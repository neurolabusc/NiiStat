function nii_stat_svr_core (xlsname, normRowCol)
% xlsname : file name to analyze
% normRowCol : normalize none [0, default], rows [1], or columns [2]
%example
% nii_stat_svr_core ('lesionacute_better_svr.tab')

if ~exist('xlsname','var') %if Excel file not specified, have user select one
   [file,pth] = uigetfile({'*.xls;*.xlsx;*.txt;*.tab','Excel/Text file';'*.txt;*.tab','Tab-delimited text (*.tab, *.txt)'},'Select the design file'); 
   if isequal(file,0), return; end;
   xlsname=[pth file];
end
if ~exist('normRowCol','var')
    normRowCol = 0; %[0, default], rows [1], or columns [2]
end
svmdir = [fileparts(which(mfilename))  filesep 'libsvm' filesep];
if ~exist(svmdir,'file') 
    error('Unable to find utility scripts folder %s',svmdir);
end
addpath(svmdir); %make sure we can find the utility scripts
%addpath c:/code/libsvm-3.11/matlab;
[~,~,x] = fileparts(xlsname);
if strcmpi(x,'.tab') || strcmpi(x,'.txt')  || strcmpi(x,'.val')
    num = tabreadSub (xlsname);
    
else
    [num, ~, ~] = xlsread (xlsname);
    num(:,1) = []; % remove first column (subject name)
end
n_subj = size (num, 1);
n_dim = size (num, 2) - 1; %final column is predictor
data = num (:, 1:n_dim);
data = requireVarSub(data);
if normRowCol ==  1% rows [1], or columns [2]
    data = normRowSub(data);
elseif normRowCol ==  2% rows [1], or columns [2]
    data = normColSub(data);
end
labels = num (:, size (num, 2));
for subj = 1:n_subj
    train_idx = setdiff (1:n_subj, subj);
    train_data = data (train_idx, :);
    train_labels = labels (train_idx);
    SVM = svmtrain (train_labels, train_data, '-s 3');
    predicted_labels(subj) = svmpredict (labels(subj), data(subj, :), SVM);  
    map (subj, :) = SVM.sv_coef' * SVM.SVs;
end
%accuracy = sum (predicted_labels' == labels) / n_subj;
%[r, p] = corr (predicted_labels', labels)
[r, p] = corrcoef (predicted_labels', labels);
fprintf('r=%g p=%g numObservations=%d numPredictors=%d\n',r(1,2),p(1,2),size (data, 1),size (data, 2));
mean_map = mean (map, 1);
z_map = mean_map ./ std (mean_map);

plot (labels, predicted_labels, 'o');
axis ([0 4 0 2]);
set (gca, 'XTick', [0 1 2 3 4]);
xlabel ('Actual score');
ylabel ('Predicted score');

function num = tabreadSub(tabname)
%read cells from tab based array. 
fid = fopen(tabname);
num = [];
row = 0;
while(1) 
	datline = fgetl(fid); % Get second row (first row of data)
	%if (length(datline)==1), break; end
    if(datline==-1), break; end %end of file
    if datline(1)=='#', continue; end; %skip lines that begin with # (comments)
    tabLocs= strfind(datline,char(9)); %findstr(char(9),datline); % find the tabs
    row = row + 1;
    if (row < 2) , continue; end; %skip first row 
    if (tabLocs < 1), continue; end; %skip first column
    dat=textscan(datline,'%s',(length(tabLocs)+1),'delimiter','\t');
    for col = 2: size(dat{1},1) %excel does not put tabs for empty cells (tabN+1)
    	num(row-1, col-1) = str2double(dat{1}{col}); %#ok<AGROW>
    end
end %while: for whole file
fclose(fid);
%end tabreadSub()

function [good_dat, good_idx] = requireVarSub (dat)
good_idx=[];
for col = 1:size(dat,2)
    if sum(isnan(dat(:,col))) > 0
       %fprintf('rejecting column %d (non-numeric data')\n',col) %
    elseif min(dat(:,col)) ~= max(dat(:,col))
        good_idx = [good_idx, col];  %#ok<AGROW>
    end
end %for col: each column
if sum(isnan(dat(:))) > 0
    fprintf('Some predictors have non-numeric values (e.g. not-a-number)\n');
end
if numel(good_idx) ~= size(dat,2)
    fprintf('Some predictors have no variability (analyzing %d of %d predictors)\n',numel(good_idx), size(dat,2));
end
good_dat = dat(:,good_idx);
%end requireVarSub()

function x = normRowSub(y)
%normalize each column for range 0..1
if size(y,2) < 2 %must have at least 2 columns
    x = y;
    return
end
mn = min(y'); %minimum
rng = max(y') - mn; %range
rng(rng == 0) = 1; %avoid divide by zero
for i = 1 : numel(mn)
    x(i,:)=(y(i,:)-mn(i)) / rng(i);
end
%normRowSub

function x = normColSub(y)
%normalize each column for range 0..1
if size(y,1) < 2 %must have at least 2 rows
    x = y;
    return
end
mn = min(y); %minimum
rng = max(y) - mn; %range
rng(rng == 0) = 1; %avoid divide by zero
for i = 1 : numel(mn)
    x(:,i)=(y(:,i)-mn(i)) / rng(i);
end
%normColSub